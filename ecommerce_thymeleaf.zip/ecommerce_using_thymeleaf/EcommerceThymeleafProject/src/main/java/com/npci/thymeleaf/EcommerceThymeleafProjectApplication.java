package com.npci.thymeleaf;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EcommerceThymeleafProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(EcommerceThymeleafProjectApplication.class, args);
	}

}
